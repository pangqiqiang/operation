#!/bin/bash
ls /data/wwwroot/www.ecloudsign.com/userdata > /dev/null 2>&1
